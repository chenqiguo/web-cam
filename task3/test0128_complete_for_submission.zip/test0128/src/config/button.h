/*
 * button.h
 *
 * Created: 1/28/2018 10:09:00 AM
 *  Author: ece-lab3
 */ 

# include <asf.h>

#ifndef BUTTON_H_
#define BUTTON_H_
#define ID_PIOA   (11)
#define PIO_PA29            (1u << 29)

//for push button
#define PUSH_BUTTON_PIO                PIOA
#define PUSH_BUTTON_PIN_MSK            PIO_PA29
#define PUSH_BUTTON_ID                 ID_PIOA
#define PUSH_BUTTON_ATTR               PIO_PULLUP | PIO_DEBOUNCE | PIO_IT_HIGH_LEVEL

//for release button
#define RELEASE_BUTTON_PIO                PIOA
#define RELEASE_BUTTON_PIN_MSK            PIO_PA29
#define RELEASE_BUTTON_ID                 ID_PIOA
#define RELEASE_BUTTON_ATTR			   PIO_PULLUP | PIO_DEBOUNCE | PIO_IT_LOW_LEVEL

volatile uint32_t button_flag;//g_ul_push_button_trigger = false;

void configure_push_button(void);
void configure_release_button(void);

#endif /* BUTTON_H_ */