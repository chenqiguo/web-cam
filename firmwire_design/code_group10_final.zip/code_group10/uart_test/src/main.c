#include <asf.h>
#include "wifi.h"
#include "conf_clock.h"
#include "conf_board.h"
#include "camera.h"
#include "timer_interface.h"

int main (void)
{
	//Define and Init
	sysclk_init();
	board_init();
	ioport_init();
	wdt_disable(WDT);

	//Timer Configuration and Start
	configure_tc();
	tc_start(TC0,0);
	
	//WiFi Configuration
	configure_usart_wifi();
	configure_wifi_comm_pin();
	configure_wifi_web_setup_pin();
	
	//WiFi Reset
	ioport_set_pin_level(WIFI_RESET,false);
	delay_ms(100);
	ioport_set_pin_level(WIFI_RESET,true);
	
	//Camera Init and Configuration
	ioport_set_pin_level(CAM_RESET_PIN, true);
	write_wifi_command("ver\n",2);
	write_wifi_command("reboot\n",3);
	
	ioport_set_pin_dir(NETWORK_STATUS_PIN, IOPORT_DIR_INPUT);
	
	while(!ioport_get_pin_level(NETWORK_STATUS_PIN))
	{
		if(web_set_flg)
		{
			web_set_flg = 0;
			write_wifi_command("setup web\n",2);
		}
	}
	
	init_camera();
	configure_camera();
	
	//Turn off the cmd prompt and cnd echo
	write_wifi_command("set system.cmd.prompt_enabled 0\n",2);
	write_wifi_command("set system.cmd.echo off\n",2);
	
	while(1)
	{	
		if(ioport_get_pin_level(NETWORK_STATUS_PIN))
		{
			write_wifi_command("poll all\r\n",2);
			process_data_wifi();
			
			if(web_set_flg)
			{
				web_set_flg = 0;
				write_wifi_command("setup web\n",2);
			}
		
			if(start_transfer)
			{
				start_transfer = 0;
				start_capture();
				find_image_len();
				write_image_to_file();
			} 
			else
			{
				process_data_wifi();
			}
		}
	}
}


