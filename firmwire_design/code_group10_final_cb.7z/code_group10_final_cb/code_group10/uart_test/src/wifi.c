#include "wifi.h"
#include "timer_interface.h"

volatile uint32_t received_byte_wifi = 0;
volatile uint32_t input_pos_wifi = 0;
volatile uint8_t start_transfer_flag = 0;
volatile uint8_t web_set_flg = 0;
volatile uint8_t start_transfer = 0;
volatile bool new_rx_wifi = 0;
volatile bool complete = 0;

/**
 * \brief Handler for incoming data from the WiFi. Should call processing_incoming_byte_wifi when a new byte arrives.
 */
void WIFI_USART_HANDLER(void)
{
	uint32_t ul_status;
	ul_status = usart_get_status(BOARD_USART);
	if (ul_status & US_CSR_RXBUFF)
	{
		usart_read(BOARD_USART, &received_byte_wifi);
		new_rx_wifi=true;
		process_incoming_byte_wifi((uint8_t)received_byte_wifi);
	}
}

/**
 * \brief Stores every incoming byte (in_byte) from the AMW136 in a buffer.
 */ 
void process_incoming_byte_wifi(uint8_t in_byte)
{
	input_line_wifi[input_pos_wifi++] = in_byte;
}

/**
 * \brief Handler for "command complete" rising-edge interrupt from AMW136. When this is triggered, it is time to process the response of the AMW136.
 */
void wifi_command_response_handler(uint32_t ul_id, uint32_t ul_mask)
{
	unused(ul_id);
	unused(ul_mask);
	process_data_wifi();
	for (uint32_t ii=0;ii<MAX_INPUT_WIFI;ii++) input_line_wifi[ii]=0;
	input_pos_wifi=0;
}

/**
 * \brief Processes the response of the AMW136, which should be stored in the buffer filled by process_incoming_byte_wifi.
 * This processing should be looking for certain response that the AMW136 should give, such as "start transfer" when it is ready to receive the image.
 */
void process_data_wifi(void)
{
	if(strstr(input_line_wifi,"# 0 WEBS")||strstr(input_line_wifi,"0,0"))
	{
		start_transfer = 1;
	}
	
	if(strstr(input_line_wifi,"Start transfer"))
	{
		start_transfer_flag = 1;
	}

	if(strstr(input_line_wifi,"Complete"))
	{
		delay_ms(100);
	}
	if(strstr(input_line_wifi,"In progress")){
	}
}

/**
 * \brief Handler for button to initiate web setup of AMW136. SHould set a flag indicating a request to initiate web setup.
 */
void wifi_web_setup_handler(uint32_t ul_id, uint32_t ul_mask)
{
	unused(ul_id);
	unused(ul_mask);
	web_set_flg = 1;
}

/**
 * \brief Configuration of USART port used to communicate with the AMW136.
 */
void configure_usart_wifi(void)
{
	gpio_configure_pin(PIN_USART0_RXD_IDX, PIN_USART0_RXD_FLAGS);
	gpio_configure_pin(PIN_USART0_TXD_IDX, PIN_USART0_TXD_FLAGS);
	gpio_configure_pin(PIN_USART0_CTS_IDX, PIN_USART0_CTS_FLAGS);
	gpio_configure_pin(PIN_USART0_RTS_IDX, PIN_USART0_RTS_FLAGS);
	static uint32_t ul_sysclk;
	const sam_usart_opt_t usart_console_settings = { BOARD_USART_BAUDRATE, US_MR_CHRL_8_BIT, US_MR_PAR_NO, US_MR_NBSTOP_1_BIT, US_MR_CHMODE_NORMAL };
	ul_sysclk = sysclk_get_peripheral_hz();
	sysclk_enable_peripheral_clock(BOARD_ID_USART);
	usart_init_hw_handshaking(BOARD_USART, &usart_console_settings, ul_sysclk);
	usart_disable_interrupt(BOARD_USART, ALL_INTERRUPT_MASK);
	usart_enable_tx(BOARD_USART);
	usart_enable_rx(BOARD_USART);
	usart_enable_interrupt(BOARD_USART, US_IER_RXRDY);
	NVIC_EnableIRQ(USART_IRQn);
}

/**
 * \brief Configuration of "command complete" rising-edge interrupt.
 */
void configure_wifi_comm_pin(void)
{
	pmc_enable_periph_clk(WIFI_COMM_ID);
	pio_set_debounce_filter(WIFI_COMM_PIO, WIFI_COMM_PIN_MASK, 10);
	pio_handler_set(WIFI_COMM_PIO, WIFI_COMM_ID, WIFI_COMM_PIN_MASK,
	WIFI_COMM_PIN_ATTR,wifi_command_response_handler);
	NVIC_EnableIRQ((IRQn_Type)WIFI_COMM_ID);
	pio_enable_interrupt(WIFI_COMM_PIO, WIFI_COMM_PIN_MASK);
}

/**
 * \brief Configuration of button interrupt to initiate web setup.
 */
void configure_wifi_web_setup_pin(void)
{
	pmc_enable_periph_clk(WEB_COMM_ID);
	pio_handler_set(WEB_COMM_PIO, WEB_COMM_ID, WEB_COMM_PIN_NUM, WEB_COMM_ATTR, wifi_web_setup_handler);
	pio_enable_interrupt(WEB_COMM_PIO, WEB_COMM_PIN_NUM);
	NVIC_EnableIRQ((IRQn_Type)WEB_COMM_ID);
	web_set_flg = 0;
}

/**
 * \brief Writes a command (comm) to the AMW136, and waits either for an acknowledgment or a timeout.
 * The timeout can be created by setting the global variable counts to zero, which will automatically
 * increment every second, and waiting while counts < cnt.
 */
void write_wifi_command(char*comm, uint8_t cnt)
{
	counts = 0;
	usart_write_line(BOARD_USART,comm);
	while (counts<cnt)
	{
		if(start_transfer_flag == 1 || start_transfer == 1)
		{
			break;
		}
	}
}

/**
 * \brief Writes and image from the SAM4S8B to the AMW136. If the length of the image is zero (i.e. the images is not valid), return.
 * Otherwise, follow this protocol which is illustrated in Appendix B.
 */
void write_image_to_file(void)
{
	if(find_image_len() == 0)
	{
		return;
	}
	else
	{
		uint8_t file_create_string[100];
		sprintf(file_create_string, "image_transfer %d\r\n",image_size);
		write_wifi_command(file_create_string,2);
		
		for(int j=0; j<image_size; j++)
		{
			usart_putchar(BOARD_USART,image_buffer[j+image_start]);
		}
		
		strstr(input_line_wifi,"Complete");
		start_transfer_flag = 0;
	}
}